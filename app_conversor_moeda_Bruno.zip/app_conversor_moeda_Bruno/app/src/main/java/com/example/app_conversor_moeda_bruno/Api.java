package com.example.app_conversor_moeda_bruno;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by ALEXEI on 18/05/2019.
 */
//Endpoint:
//https://api.hgbrasil.com/finance.php?format=json-cors&fields=currencies&key=1baded04

public interface Api {

    String BASE_URL = "https://api.hgbrasil.com/";

    @GET("finance.php?format=json-cors&fields=currencies&key=1baded04")
    Call<Dados> verCotacao();
}


