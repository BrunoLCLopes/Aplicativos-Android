package com.example.app_conversor_moeda_bruno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    TextView tv_real;

    EditText edt_dolar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_real = findViewById(R.id.tv_real);
        edt_dolar = findViewById(R.id.edt_dolar);
    }

    public void consultar_clique(View v){
        // Pegar o Valor Digitado
        final double valor = Double.parseDouble(edt_dolar.getText().toString());

        Api api = Conexao.conecta();

        //Faz a Chamada no WebService
        Call<Dados> resposta = api.verCotacao();

        //Retorno
        resposta.enqueue(new Callback<Dados>() {
            @Override
            public void onResponse(Call<Dados> call, Response<Dados> response) {
                // Pega o retorno
                Dados retorno = response.body();
                // Pega o Valor do Dollar
                String valor_dolar = retorno.results.currencies.USD.buy;
                // Mostrar o Valor
                tv_real.setText("Valor em Real R$ "+ valor * Double.parseDouble(valor_dolar));

            }

            @Override
            public void onFailure(Call<Dados> call, Throwable t) {
                Toast.makeText(getApplicationContext(),"Erro !", Toast.LENGTH_LONG).show();
            }
        });
    }
}