package com.example.app_conversor_moeda_bruno;

/**
 * Created by ALEXEI on 27/05/2019.
 */
public class Dados {

    Results results;

    public class Results{
        Currencies currencies;

        public class Currencies{
            USD USD;

            public class USD {
                String buy;
            }

        }
    }
}

