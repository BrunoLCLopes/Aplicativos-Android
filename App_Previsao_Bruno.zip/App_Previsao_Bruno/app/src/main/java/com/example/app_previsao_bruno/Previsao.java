package com.example.app_previsao_bruno;

public class Previsao {
    Results results;

    public class Results {
        String temp, description, humidity;
    }
}
