package com.example.app_previsao_bruno;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface Api {
    String BASE_URL = "https://api.hgbrasil.com/";

    // Aqui ele ira Buscar o arquivo enviado de um codigo da cidade para consultar na internet
    @GET("weather.php")
    Call<Previsao> verPrevisao(@Query("woeid") String woeid);
}
