package com.example.app_previsao_bruno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {


    TextView tv_temperatura, tv_situacao, tv_umidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_situacao = findViewById(R.id.tv_situacao);
        tv_temperatura = findViewById(R.id.tv_temperatura);
        tv_umidade = findViewById(R.id.tv_umidade);


        Retrofit retrofit = new Retrofit.Builder().baseUrl(Api.BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();

        Api api = retrofit.create(Api.class);

        Call<Previsao> call = api.verPrevisao("423267");
        call.enqueue(new Callback<Previsao>() {
            @Override
            public void onResponse(Call<Previsao> call, Response<Previsao> response) {
                // Pegou o Retorno
                Previsao retorno = response.body();
                // Guardar Variaveis
                String temperatura = retorno.results.temp;
                String situacao = retorno.results.description;
                String umidade = retorno.results.humidity;
                //Mostrar dados
                tv_temperatura.setText("Temperatura: "+temperatura+"°");
                tv_situacao.setText("Situação: "+situacao);
                tv_umidade.setText("Umidade: "+umidade);
            }

            @Override
            public void onFailure(Call<Previsao> call, Throwable t) {
                // Se der Algum erro
                Toast.makeText(getApplicationContext(), "Erro na Conexão", Toast.LENGTH_LONG).show();
            }
        });
    }
}