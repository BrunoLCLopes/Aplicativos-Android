package com.example.app_lista_filme_bruno;

import java.util.ArrayList;

import retrofit2.http.GET;
import retrofit2.Call;

public interface Api {
    String BASE_URL = "https://sujeitoprogramador.com/";

    //Buscar na internet pelo get
    @GET("r-api/?api=filmes")
    Call<ArrayList<Filme>> getFilmes();
}
// Com isso fará com que se conecte na internet e pegue os dados