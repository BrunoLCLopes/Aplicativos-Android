package com.example.app_lista_filme_bruno;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    ListView lst_filmes;

    //Guardar o filme escolhido

    public static Filme filme_escolhido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lst_filmes = findViewById(R.id.lst_filmes);

        // Criar o retrofit
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Api.BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();


        Api api = retrofit.create(Api.class);

        // Obter os dados da Internet

        Call<ArrayList<Filme>> call = api.getFilmes();

        // Trabalho com retrono via internt
        call.enqueue(new Callback<ArrayList<Filme>>() {
            @Override
            public void onResponse(Call<ArrayList<Filme>> call, Response<ArrayList<Filme>> response) {
                ArrayList<Filme> filmes = response.body();  // Pegar o json e transformar em objetos
                ArrayAdapter<Filme> adaptador = new ArrayAdapter<>(getApplicationContext(),R.layout.item,R.id.tv_filme,filmes);

                lst_filmes.setAdapter(adaptador);

                // Ao CLickar no Filme

                lst_filmes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        filme_escolhido = (Filme) lst_filmes.getItemAtPosition(i);
                        startActivity(new Intent(getApplicationContext(), TelaDetalhe.class));
                    }
                });
            }

            @Override
            public void onFailure(Call<ArrayList<Filme>> call, Throwable t) {
                //erro
                Toast.makeText(getApplicationContext(),"Erro de Conexão", Toast.LENGTH_LONG).show();
            }
        });

    }
}