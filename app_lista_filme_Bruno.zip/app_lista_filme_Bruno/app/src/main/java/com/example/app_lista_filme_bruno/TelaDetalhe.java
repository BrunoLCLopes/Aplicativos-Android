package com.example.app_lista_filme_bruno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class TelaDetalhe extends AppCompatActivity {

    TextView tv_sinopse;
    ImageView img_foto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_detalhe);

        tv_sinopse = findViewById(R.id.tv_sinopse);
        img_foto = findViewById(R.id.img_foto);

        //Mostrar a sinopse
        tv_sinopse.setText(MainActivity.filme_escolhido.getSinopse());

        // Pego a url da foto do filme
        String url_imagem = MainActivity.filme_escolhido.getFoto();

        //Mostrar imagem do filme que veio da internt
        Picasso.with(this).load(url_imagem).into(img_foto);
    }
}